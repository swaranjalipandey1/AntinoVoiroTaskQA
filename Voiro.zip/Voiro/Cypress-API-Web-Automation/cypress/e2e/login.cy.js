describe('template spec', () => {
    it('passes', () => {
        cy.visit("https://demo.voiro.com/phoenix/")
        

    })
  })